Instructions/Notes

Each folder contains the referent files.

AccessDB- RetroWave's legacy system
CSV Files- data files output by the python script
Deliverables- contains the ETL, Data Cube, Report Server, Power BI Dashboards, Final report, and workflow diagram. 
Script Files- contains the scripts necessary for generating the CSV files and SQL database. 

Instructions on how to re-create this solution are included in the report. 
