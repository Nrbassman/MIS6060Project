import pandas as pd
import random
import numpy as np
from faker import Faker
from datetime import datetime, timedelta
import os

# ----------------- SET RANDOM SEEDS FOR REPRODUCIBILITY -----------------
random.seed(42)
np.random.seed(42)

# ----------------- CONFIGURATION -----------------
faker = Faker()
output_path = r"C:\Users\nicob\OneDrive\MIS6060ProjectFolder\Script Files"
os.makedirs(output_path, exist_ok=True)

# ----------------- TIMEFRAME SETTINGS (Q3 2024) -----------------
q3_start = datetime(2024, 7, 1)
q3_end = datetime(2024, 9, 30)

# Build a list of all dates in Q3 2024 with weekly weights.
all_dates = pd.date_range(start=q3_start, end=q3_end).to_pydatetime().tolist()
date_weights = []
for dt in all_dates:
    weekday = dt.weekday()  # Monday=0, Sunday=6
    if weekday in [0, 1, 2, 3]:
        weight = 1
    elif weekday == 4:
        weight = 1.5
    else:
        weight = 2
    date_weights.append(weight)

def get_weighted_date():
    chosen_date = random.choices(all_dates, weights=date_weights, k=1)[0]
    return chosen_date.date()

def get_random_datetime():
    date_part = get_weighted_date()
    hour = random.randint(10, 21)
    minute = random.randint(0, 59)
    second = random.randint(0, 59)
    return datetime.combine(date_part, datetime.min.time()) + timedelta(hours=hour, minutes=minute, seconds=second)

# ----------------- DIMENSION TABLES -----------------

# DimLocation (Updated Names)
locations = [
    {"LocationID": "LOC001", "LocationName": "RetroWave Downtown", "Address": "123 Woodward Ave", "City": "Detroit", "State": "MI", "ZipCode": "48201"},
    {"LocationID": "LOC002", "LocationName": "RetroWave Midtown", "Address": "456 Gratiot Blvd", "City": "Detroit", "State": "MI", "ZipCode": "48207"},
    {"LocationID": "LOC003", "LocationName": "RetroWave Royal Oak", "Address": "789 Cass St", "City": "Royal Oak", "State": "MI", "ZipCode": "48067"}
]
df_locations = pd.DataFrame(locations)
df_locations.to_csv(os.path.join(output_path, "DimLocation.csv"), index=False, encoding="utf-8-sig")
location_ids = [loc["LocationID"] for loc in locations]

# DimPlayer
num_players = random.randint(3500, 4500)
member_cutoff = int(num_players * random.uniform(0.15, 0.3))
players = []
for i in range(1, num_players + 1):
    pid = f"PLYR{i:04}"
    is_member = (i <= member_cutoff)
    if is_member:
        name = faker.name()
        dob = faker.date_of_birth(minimum_age=10, maximum_age=45).strftime('%Y-%m-%d')
        email = faker.email()
        phone = faker.numerify(text="###-###-####")
        join_date = faker.date_between(start_date='-1y', end_date='today').strftime('%Y-%m-%d')
        status = "Member"
        tier = random.choices(["Bronze", "Silver", "Gold"], weights=[70, 20, 10], k=1)[0]
    else:
        name = f"Guest {i}"
        dob = ""
        email = "guest@retrowave.com"
        phone = ""
        join_date = ""
        status = "Guest"
        tier = ""
    players.append([pid, name, dob, email, phone, join_date, status, tier])

df_players = pd.DataFrame(players, columns=[
    "PlayerID", "Name", "DOB", "Email", "Phone", "JoinDate", "MembershipStatus", "MembershipTier"
])
df_players.to_csv(os.path.join(output_path, "DimPlayer.csv"), index=False, encoding="utf-8-sig")
player_ids = df_players["PlayerID"].tolist()

# DimGame
game_catalog = [
    ("Pac-Man", "Namco", "Classic"),
    ("Donkey Kong", "Nintendo", "Classic"),
    ("Street Fighter II", "Capcom", "Fighting"),
    ("Mortal Kombat", "Midway", "Fighting"),
    ("Dance Dance Revolution", "Konami", "Rhythm"),
    ("Galaga", "Namco", "Classic"),
    ("Time Crisis", "Namco", "Shooting"),
    ("Daytona USA", "Sega", "Racing"),
    ("NBA Jam", "Midway", "Sports"),
    ("Teenage Mutant Ninja Turtles", "Konami", "Fighting"),
    ("Asteroids", "Atari", "Classic"),
    ("Space Invaders", "Taito", "Classic"),
    ("Centipede", "Atari", "Classic"),
    ("Cruis'n USA", "Midway", "Racing"),
    ("Frogger", "Konami", "Classic"),
    ("The Simpsons", "Konami", "Fighting"),
    ("Tekken 3", "Namco", "Fighting"),
    ("Marvel vs. Capcom", "Capcom", "Fighting"),
    ("Virtua Fighter", "Sega", "Fighting"),
    ("Hydro Thunder", "Midway", "Racing"),
    ("Initial D Arcade Stage", "Sega", "Racing"),
    ("Mario Kart Arcade GP", "Namco", "Racing"),
    ("House of the Dead", "Sega", "Shooting"),
    ("After Burner", "Sega", "Shooting"),
    ("OutRun", "Sega", "Racing"),
    ("Golden Tee", "Incredible Technologies", "Sports"),
    ("Big Buck Hunter", "Play Mechanix", "Shooting"),
    ("Air Hockey Pro", "Dynamo", "Sports"),
    ("Skeeball Classic", "Skeeball Inc.", "Redemption"),
    ("Wheel of Fortune", "Raw Thrills", "Redemption"),
    ("Trivia Whiz", "Merit", "Redemption"),
    ("Ice Ball FX", "ICE", "Redemption"),
    ("Quick Drop", "Bay Tek", "Redemption"),
    ("Mega Stacker", "LAI Games", "Redemption"),
    ("Ticket Time", "Smart Industries", "Redemption"),
    ("Whack N Win", "ICE", "Redemption"),
    ("Cyclone", "ICE", "Redemption"),
    ("Down the Clown", "ICE", "Redemption"),
    ("Rerex", "Amuzy", "Redemption"),
    ("Halo: Fireteam Raven", "Raw Thrills", "Shooting"),
    ("Jurassic Park Arcade", "Raw Thrills", "Shooting"),
    ("The Walking Dead", "Raw Thrills", "Shooting"),
    ("Injustice Arcade", "Raw Thrills", "Fighting"),
    ("Cruis'n Blast", "Raw Thrills", "Racing"),
    ("Mario & Sonic Olympics", "Sega", "Sports"),
    ("Let's Go Island", "Sega", "Shooting"),
    ("Dead Heat Riders", "Namco", "Racing"),
    ("Pong Knockout", "Atari", "Classic"),
    ("Speed of Light", "LAI Games", "Redemption"),
    ("Jumpin Jackpot", "Konami", "Redemption")
]
selected_games = random.sample(game_catalog, 50)
games = []
game_category_weights = {"Classic": 1.5, "Fighting": 1.0, "Rhythm": 0.8, "Shooting": 1.2, "Racing": 1.3, "Sports": 1.2, "Redemption": 0.7}
for i, (title, manufacturer, category) in enumerate(selected_games):
    gid = f"G{i+1:03d}"
    mtype = random.choice(["Video", "Mechanical", "Hybrid"])
    install = faker.date_between(start_date='-10y', end_date='-1d').strftime('%Y-%m-%d')
    games.append([gid, title, category, mtype, manufacturer, install])

df_games = pd.DataFrame(games, columns=[
    "GameID", "GameName", "Category", "MachineType", "Manufacturer", "InstallDate"
])
df_games.to_csv(os.path.join(output_path, "DimGame.csv"), index=False, encoding="utf-8-sig")
game_ids = df_games["GameID"].tolist()

# Location-specific game preference multipliers
location_game_preference = {
    "LOC001": {"Classic": 1.0, "Fighting": 1.0, "Rhythm": 1.0, "Shooting": 1.0, "Racing": 1.0, "Sports": 1.0, "Redemption": 1.0},
    "LOC002": {"Classic": 0.9, "Fighting": 1.1, "Rhythm": 0.8, "Shooting": 1.2, "Racing": 0.9, "Sports": 0.95, "Redemption": 1.1},
    "LOC003": {"Classic": 1.1, "Fighting": 0.95, "Rhythm": 1.0, "Shooting": 0.85, "Racing": 1.2, "Sports": 1.05, "Redemption": 0.9}
}

# Precompute adjusted game weights for each location
import copy
location_adjusted_game_weights = {}
df_games_tuples = df_games.itertuples(index=False)
for loc in location_ids:
    adjusted_weights = []
    for row in df_games_tuples:
        base_weight = game_category_weights.get(row.Category, 1)
        loc_modifier = location_game_preference.get(loc, {}).get(row.Category, 1)
        adjusted_weights.append(base_weight * loc_modifier)
    # Because iterrows/itertuples is only consumed once, re-init:
    df_games_tuples = df_games.itertuples(index=False)
    location_adjusted_game_weights[loc] = adjusted_weights

# DimActivity
activity_base = [
    ("Bowling", "4-lane retro bowling alley", 30.00),
    ("Pool", "Classic bar pool tables", 15.00),
    ("Darts", "Arcade-style darts area", 10.00)
]
activity_rows = []
act_id = 1
# Downtown gets all activities
for name, desc, rate in activity_base:
    activity_rows.append([f"ACT{act_id:03}", name, desc, rate, "LOC001"])
    act_id += 1
# Other locations get 1-2 random activities
for loc in location_ids[1:]:
    chosen = random.sample(activity_base, random.randint(1, 2))
    for name, desc, rate in chosen:
        activity_rows.append([f"ACT{act_id:03}", name, desc, rate, loc])
        act_id += 1
df_activity = pd.DataFrame(activity_rows, columns=[
    "ActivityID", "ActivityType", "Description", "PricePerHour", "LocationID"
])
df_activity.to_csv(os.path.join(output_path, "DimActivity.csv"), index=False, encoding="utf-8-sig")

# DimPrize
prize_catalog = {
    "Candy & Snacks": [("Fun Dip", 25), ("Skittles", 30), ("Lollipop Pack", 15), ("Chocolate Bar", 35)],
    "Toys & Trinkets": [("Sticky Hand", 20), ("Mini Puzzle Cube", 50), ("Bouncy Ball", 25), ("Finger Skateboard", 60)],
    "Plush & Stuffed": [("Small Plush Bear", 150), ("Stuffed Dinosaur", 200), ("Plush Cat", 180)],
    "Electronics": [("Bluetooth Speaker", 2000), ("LED Strip Lights", 1200), ("Wireless Earbuds", 2500)],
    "Games & Collectibles": [("Pokemon Card Pack", 300), ("Mini Board Game", 400), ("Keychain Set", 150)],
    "Premium": [("Electric Guitar", 8000), ("Gaming Headset", 3500), ("Drone", 6000)],
    "Stationery": [("Notebook Set", 100), ("Gel Pen Pack", 90), ("Sticker Book", 120)]
}
prizes = []
prize_id = 1
while len(prizes) < 45:
    for cat, items in prize_catalog.items():
        for name, cost in items:
            if len(prizes) >= 45:
                break
            prizes.append([
                f"PRZ{prize_id:03}", name, cat, cost,
                random.randint(10, 150), random.randint(5, 25)
            ])
            prize_id += 1
df_prize = pd.DataFrame(prizes, columns=[
    "PrizeID", "PrizeName", "Category", "TicketCost", "QuantityInStock", "RestockThreshold"
])
df_prize.to_csv(os.path.join(output_path, "DimPrize.csv"), index=False, encoding="utf-8-sig")
prize_ids = df_prize["PrizeID"].tolist()

# Global base prize weights
prize_weight_map = {
    "Candy & Snacks": 2.0,
    "Toys & Trinkets": 1.5,
    "Plush & Stuffed": 1.2,
    "Electronics": 0.5,
    "Games & Collectibles": 1.0,
    "Premium": 0.3,
    "Stationery": 1.0
}
location_prize_preference = {
    "LOC001": {"Candy & Snacks": 1.0, "Toys & Trinkets": 1.0, "Plush & Stuffed": 1.0, "Electronics": 1.0,
               "Games & Collectibles": 1.0, "Premium": 1.0, "Stationery": 1.0},
    "LOC002": {"Candy & Snacks": 0.9, "Toys & Trinkets": 1.1, "Plush & Stuffed": 0.95, "Electronics": 1.2,
               "Games & Collectibles": 0.9, "Premium": 1.1, "Stationery": 1.0},
    "LOC003": {"Candy & Snacks": 1.2, "Toys & Trinkets": 0.85, "Plush & Stuffed": 1.05, "Electronics": 0.8,
               "Games & Collectibles": 1.1, "Premium": 0.9, "Stationery": 0.95}
}
prize_category_map = {row["PrizeID"]: row["Category"] for _, row in df_prize.iterrows()}

# Precompute adjusted prize weights for each location
location_adjusted_prize_weights = {}
for loc in location_ids:
    adjusted_weights = []
    for pid in prize_ids:
        base_weight = prize_weight_map.get(prize_category_map.get(pid, ""), 1)
        loc_modifier = location_prize_preference[loc].get(prize_category_map.get(pid, ""), 1)
        adjusted_weights.append(base_weight * loc_modifier)
    location_adjusted_prize_weights[loc] = adjusted_weights

# DimEvent
event_types = ['Game Tournament', 'Bowling League Night', 'Darts League Night', 'Pool League Night']
event_themes = ['Summer Showdown', 'Token Frenzy', 'Pixel Party', 'Boss Rush']
events = []
for i in range(26):
    evt_id = f"EVT{i+1:03}"
    evt_type = random.choice(event_types)
    evt_theme = random.choice(event_themes)
    evt_name = f"{evt_type} – {evt_theme}"
    evt_date = get_weighted_date().strftime('%Y-%m-%d')
    duration = random.choice([2, 3, 4])
    attendance = random.randint(30, 150)
    revenue = round(random.uniform(10, 25) * attendance, 2)
    events.append([evt_id, evt_name, evt_type, evt_date, duration, attendance, revenue])
df_event = pd.DataFrame(events, columns=[
    "EventID", "EventName", "EventType", "Date", "DurationHrs", "Attendance", "Revenue"
])
df_event.to_csv(os.path.join(output_path, "DimEvent.csv"), index=False, encoding="utf-8-sig")
event_ids = df_event["EventID"].tolist()

# ----------------- FACT TABLES -----------------

# FactArcadeTransactions
arcade_transactions = []
arcade_count = random.randint(100000, 180000)
# Adjusted location weights: e.g. 45% Downtown, 25% Midtown, 30% Royal Oak
location_weights = [0.45, 0.25, 0.30]

for i in range(arcade_count):
    trx_id = f"TRX{i+1:06}"
    player = random.choice(player_ids)
    # fixed ~20% chance for an event
    event_id = random.choice(event_ids) if random.random() < 0.2 else ""
    # choose location
    chosen_location = random.choices(location_ids, weights=location_weights, k=1)[0]
    # adjusted game weights for that location
    adjusted_game_weights = location_adjusted_game_weights[chosen_location]
    game = random.choices(game_ids, weights=adjusted_game_weights, k=1)[0]
    start_dt = get_random_datetime()
    end_dt = start_dt + timedelta(minutes=random.randint(1, 15))
    tokens_used = random.choices(range(1, 11), weights=[20,18,16,14,12,10,8,6,4,2], k=1)[0]
    tickets_earned = int(np.random.exponential(scale=30)) + 20
    tickets_earned = max(20, min(tickets_earned, 200))
    payment_method = random.choices(["Cash", "Card", "Mobile"], weights=[40, 40, 20], k=1)[0]
    score = random.randint(100, 10000)
    timestamp = start_dt.strftime('%Y-%m-%d %H:%M:%S')
    arcade_transactions.append([
        trx_id, player, event_id, game,
        start_dt.strftime('%Y-%m-%d %H:%M:%S'),
        end_dt.strftime('%Y-%m-%d %H:%M:%S'),
        tokens_used, tickets_earned, payment_method, score, timestamp, chosen_location
    ])
df_arcade = pd.DataFrame(arcade_transactions, columns=[
    "TransactionID", "PlayerID", "EventID", "GameID", "PlayStart", "PlayEnd",
    "TokensUsed", "TicketsEarned", "PaymentMethod", "Score", "Timestamp", "LocationID"
])
df_arcade.to_csv(os.path.join(output_path, "FactArcadeTransactions.csv"), index=False, encoding="utf-8-sig")

# FactPrizeRedemptions
prize_redemptions = []
prize_redemption_count = random.randint(80000, 140000)
for i in range(prize_redemption_count):
    red_id = f"RDM{i+1:05}"
    player = random.choice(player_ids)
    # choose location
    chosen_location = random.choices(location_ids, weights=location_weights, k=1)[0]
    adjusted_prize_weights = location_adjusted_prize_weights[chosen_location]
    prize = random.choices(prize_ids, weights=adjusted_prize_weights, k=1)[0]
    qty = random.randint(1, 3)
    base_cost = df_prize.loc[df_prize["PrizeID"] == prize, "TicketCost"].values[0]
    ticket_cost = round(qty * base_cost * random.uniform(0.95, 1.05), 2)
    ts = get_random_datetime().strftime('%Y-%m-%d %H:%M:%S')
    prize_redemptions.append([
        red_id, player, prize, chosen_location,
        qty, ticket_cost, ts
    ])
df_redemptions = pd.DataFrame(prize_redemptions, columns=[
    "RedemptionID", "PlayerID", "PrizeID", "LocationID", "Quantity", "TicketCost", "Timestamp"
])
df_redemptions.to_csv(os.path.join(output_path, "FactPrizeRedemptions.csv"), index=False, encoding="utf-8-sig")

# FactActivityTransactions
activity_transactions = []
activity_count = random.randint(4000, 6000)
for i in range(activity_count):
    trx_id = f"ACTTRX{i+1:05}"
    player = random.choice(player_ids)
    act = random.choice(activity_rows)
    act_id, act_type, _, price_per_hour, act_location = act
    dt = get_random_datetime()
    date_str = dt.strftime('%Y-%m-%d')
    start_time_str = dt.strftime('%H:%M')
    duration = random.choice([1, 1.5, 2, 2.5, 3])
    party_size = random.randint(1, 8)
    revenue = round(duration * price_per_hour * random.uniform(0.95, 1.05), 2)
    reserved = "Yes" if random.random() < random.uniform(0.2, 0.4) else "No"
    is_birthday = "Yes" if (reserved == "Yes" and random.random() < 0.4) else "No"
    activity_transactions.append([
        trx_id, player, act_id, act_type, date_str, start_time_str,
        duration, act_location, party_size, revenue, reserved, is_birthday
    ])
df_activity_trans = pd.DataFrame(activity_transactions, columns=[
    "TransactionID", "PlayerID", "ActivityID", "ActivityType", "Date", "StartTime",
    "DurationHrs", "LocationID", "PartySize", "Revenue", "Reserved", "IsBirthday"
])
df_activity_trans.to_csv(os.path.join(output_path, "FactActivityTransactions.csv"), index=False, encoding="utf-8-sig")

print("Data generation complete. CSV files are saved to:", output_path)
