USE [master]
GO
/****** Object:  Database [RetroWaveDW]    Script Date: 4/23/2025 10:44:36 AM ******/
CREATE DATABASE [RetroWaveDW]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'RetroWaveDW', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\RetroWaveDW.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'RetroWaveDW_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\RetroWaveDW_log.ldf' , SIZE = 401408KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [RetroWaveDW] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [RetroWaveDW].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [RetroWaveDW] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [RetroWaveDW] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [RetroWaveDW] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [RetroWaveDW] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [RetroWaveDW] SET ARITHABORT OFF 
GO
ALTER DATABASE [RetroWaveDW] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [RetroWaveDW] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [RetroWaveDW] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [RetroWaveDW] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [RetroWaveDW] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [RetroWaveDW] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [RetroWaveDW] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [RetroWaveDW] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [RetroWaveDW] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [RetroWaveDW] SET  ENABLE_BROKER 
GO
ALTER DATABASE [RetroWaveDW] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [RetroWaveDW] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [RetroWaveDW] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [RetroWaveDW] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [RetroWaveDW] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [RetroWaveDW] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [RetroWaveDW] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [RetroWaveDW] SET RECOVERY FULL 
GO
ALTER DATABASE [RetroWaveDW] SET  MULTI_USER 
GO
ALTER DATABASE [RetroWaveDW] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [RetroWaveDW] SET DB_CHAINING OFF 
GO
ALTER DATABASE [RetroWaveDW] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [RetroWaveDW] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [RetroWaveDW] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [RetroWaveDW] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'RetroWaveDW', N'ON'
GO
ALTER DATABASE [RetroWaveDW] SET QUERY_STORE = OFF
GO
USE [RetroWaveDW]
GO
/****** Object:  Table [dbo].[FactActivityTransactions]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactActivityTransactions](
	[TransactionID] [varchar](15) NOT NULL,
	[PlayerID] [varchar](10) NULL,
	[ActivityID] [varchar](10) NULL,
	[ActivityType] [varchar](30) NULL,
	[Date] [date] NULL,
	[StartTime] [varchar](10) NULL,
	[DurationHrs] [decimal](3, 1) NULL,
	[LocationID] [varchar](10) NULL,
	[PartySize] [int] NULL,
	[Revenue] [money] NULL,
	[Reserved] [varchar](10) NULL,
	[IsBirthday] [varchar](10) NULL,
 CONSTRAINT [PK__FactActi__55433A4B979FC3BF] PRIMARY KEY CLUSTERED 
(
	[TransactionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FactActivityTransactions]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_FactActivityTransactions]
AS
SELECT   TransactionID, PlayerID, ActivityID, ActivityType, Date, CAST(Date AS DATE) AS DateKey, StartTime, DurationHrs, LocationID, PartySize, Revenue, Reserved, IsBirthday
FROM      dbo.FactActivityTransactions
GO
/****** Object:  Table [dbo].[FactArcadeTransactions]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactArcadeTransactions](
	[TransactionID] [varchar](15) NOT NULL,
	[PlayerID] [varchar](10) NULL,
	[EventID] [varchar](10) NULL,
	[GameID] [varchar](10) NULL,
	[PlayStart] [datetime] NULL,
	[PlayEnd] [datetime] NULL,
	[TokensUsed] [int] NULL,
	[TicketsEarned] [int] NULL,
	[PaymentMethod] [varchar](20) NULL,
	[Score] [int] NULL,
	[Timestamp] [datetime] NULL,
	[LocationID] [varchar](10) NULL,
PRIMARY KEY CLUSTERED 
(
	[TransactionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FactArcadeTransactions]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_FactArcadeTransactions]
AS
SELECT   TransactionID, PlayerID, NULLIF (EventID, '') AS EventID, GameID, LocationID, Timestamp, CAST(Timestamp AS DATE) AS DateKey, PlayStart, PlayEnd, TokensUsed, TicketsEarned, PaymentMethod, Score
FROM      dbo.FactArcadeTransactions
GO
/****** Object:  Table [dbo].[FactPrizeRedemptions]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactPrizeRedemptions](
	[RedemptionID] [varchar](15) NOT NULL,
	[PlayerID] [varchar](10) NULL,
	[PrizeID] [varchar](10) NULL,
	[LocationID] [varchar](10) NULL,
	[Quantity] [int] NULL,
	[TicketCost] [int] NULL,
	[Timestamp] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[RedemptionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FactPrizeRedemptions]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_FactPrizeRedemptions]
AS
SELECT   RedemptionID, PlayerID, PrizeID, LocationID, Timestamp, CAST(Timestamp AS DATE) AS DateKey, Quantity, TicketCost
FROM      dbo.FactPrizeRedemptions
GO
/****** Object:  Table [dbo].[DimDate]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimDate](
	[DateKey] [date] NOT NULL,
	[FullDateName]  AS (format([DateKey],'MMMM dd, yyyy')),
	[Year] [int] NULL,
	[Quarter] [int] NULL,
	[Month] [int] NULL,
	[MonthName]  AS (datename(month,[DateKey])),
	[Day] [int] NULL,
	[DayOfWeek] [int] NULL,
	[DayName]  AS (datename(weekday,[DateKey])),
PRIMARY KEY CLUSTERED 
(
	[DateKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_DimDate]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   VIEW [dbo].[vw_DimDate] AS
SELECT
    DateKey,
    FullDateName,
    Year,
    Quarter,
    Month,
    MonthName,
    Day,
    DayOfWeek,
    DayName
FROM dbo.DimDate;
GO
/****** Object:  Table [dbo].[DimPlayer]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimPlayer](
	[PlayerID] [varchar](10) NOT NULL,
	[Name] [nvarchar](150) NULL,
	[DOB] [date] NULL,
	[Email] [nvarchar](150) NULL,
	[Phone] [nvarchar](20) NULL,
	[JoinDate] [date] NULL,
	[MembershipStatus] [varchar](30) NULL,
	[MembershipTier] [varchar](30) NULL,
PRIMARY KEY CLUSTERED 
(
	[PlayerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_PlayerMembership]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_PlayerMembership] AS 
SELECT
    PlayerID,
    JoinDate,
    MembershipStatus,
    MembershipTier,
    CAST(JoinDate AS DATE) AS DateKey
FROM dbo.DimPlayer
WHERE JoinDate BETWEEN '2024-07-01' AND '2024-09-30';
GO
/****** Object:  Table [dbo].[DimActivity]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimActivity](
	[ActivityID] [varchar](10) NOT NULL,
	[ActivityType] [nvarchar](50) NULL,
	[Description] [nvarchar](150) NULL,
	[PricePerHour] [money] NULL,
	[LocationID] [varchar](10) NULL,
PRIMARY KEY CLUSTERED 
(
	[ActivityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DimEvent]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimEvent](
	[EventID] [varchar](10) NOT NULL,
	[EventName] [nvarchar](50) NULL,
	[EventType] [varchar](50) NULL,
	[Date] [date] NULL,
	[DurationHrs] [int] NULL,
	[Attendance] [int] NULL,
	[Revenue] [money] NULL,
 CONSTRAINT [PK__DimEvent__7944C870EEF4E779] PRIMARY KEY CLUSTERED 
(
	[EventID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DimGame]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimGame](
	[GameID] [varchar](10) NOT NULL,
	[GameName] [nvarchar](30) NULL,
	[Category] [varchar](30) NULL,
	[MachineType] [varchar](30) NULL,
	[Manufacturer] [nvarchar](30) NULL,
	[InstallDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[GameID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DimLocation]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimLocation](
	[LocationID] [varchar](10) NOT NULL,
	[LocationName] [nvarchar](30) NULL,
	[Address] [nvarchar](150) NULL,
	[City] [nvarchar](50) NULL,
	[State] [nvarchar](2) NULL,
	[ZipCode] [varchar](10) NULL,
 CONSTRAINT [PK__DimLocat__E7FEA4772E1B928B] PRIMARY KEY CLUSTERED 
(
	[LocationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DimPrize]    Script Date: 4/23/2025 10:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimPrize](
	[PrizeID] [varchar](10) NOT NULL,
	[PrizeName] [nvarchar](50) NULL,
	[Category] [varchar](30) NULL,
	[TicketCost] [money] NULL,
	[QuantityInStock] [int] NULL,
	[RestockThreshold] [int] NULL,
 CONSTRAINT [PK__DimPrize__5C36F4BB6CB50244] PRIMARY KEY CLUSTERED 
(
	[PrizeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[DimActivity]  WITH CHECK ADD  CONSTRAINT [FK__DimActivi__Locat__2E1BDC42] FOREIGN KEY([LocationID])
REFERENCES [dbo].[DimLocation] ([LocationID])
GO
ALTER TABLE [dbo].[DimActivity] CHECK CONSTRAINT [FK__DimActivi__Locat__2E1BDC42]
GO
ALTER TABLE [dbo].[FactActivityTransactions]  WITH CHECK ADD  CONSTRAINT [FK__FactActiv__Activ__3C69FB99] FOREIGN KEY([ActivityID])
REFERENCES [dbo].[DimActivity] ([ActivityID])
GO
ALTER TABLE [dbo].[FactActivityTransactions] CHECK CONSTRAINT [FK__FactActiv__Activ__3C69FB99]
GO
ALTER TABLE [dbo].[FactActivityTransactions]  WITH CHECK ADD  CONSTRAINT [FK__FactActiv__Locat__3D5E1FD2] FOREIGN KEY([LocationID])
REFERENCES [dbo].[DimLocation] ([LocationID])
GO
ALTER TABLE [dbo].[FactActivityTransactions] CHECK CONSTRAINT [FK__FactActiv__Locat__3D5E1FD2]
GO
ALTER TABLE [dbo].[FactActivityTransactions]  WITH CHECK ADD  CONSTRAINT [FK__FactActiv__Playe__3B75D760] FOREIGN KEY([PlayerID])
REFERENCES [dbo].[DimPlayer] ([PlayerID])
GO
ALTER TABLE [dbo].[FactActivityTransactions] CHECK CONSTRAINT [FK__FactActiv__Playe__3B75D760]
GO
ALTER TABLE [dbo].[FactArcadeTransactions]  WITH CHECK ADD  CONSTRAINT [FK__FactArcad__Event__31EC6D26] FOREIGN KEY([EventID])
REFERENCES [dbo].[DimEvent] ([EventID])
GO
ALTER TABLE [dbo].[FactArcadeTransactions] CHECK CONSTRAINT [FK__FactArcad__Event__31EC6D26]
GO
ALTER TABLE [dbo].[FactArcadeTransactions]  WITH CHECK ADD FOREIGN KEY([GameID])
REFERENCES [dbo].[DimGame] ([GameID])
GO
ALTER TABLE [dbo].[FactArcadeTransactions]  WITH CHECK ADD  CONSTRAINT [FK__FactArcad__Locat__33D4B598] FOREIGN KEY([LocationID])
REFERENCES [dbo].[DimLocation] ([LocationID])
GO
ALTER TABLE [dbo].[FactArcadeTransactions] CHECK CONSTRAINT [FK__FactArcad__Locat__33D4B598]
GO
ALTER TABLE [dbo].[FactArcadeTransactions]  WITH CHECK ADD FOREIGN KEY([PlayerID])
REFERENCES [dbo].[DimPlayer] ([PlayerID])
GO
ALTER TABLE [dbo].[FactPrizeRedemptions]  WITH CHECK ADD  CONSTRAINT [FK__FactPrize__Locat__38996AB5] FOREIGN KEY([LocationID])
REFERENCES [dbo].[DimLocation] ([LocationID])
GO
ALTER TABLE [dbo].[FactPrizeRedemptions] CHECK CONSTRAINT [FK__FactPrize__Locat__38996AB5]
GO
ALTER TABLE [dbo].[FactPrizeRedemptions]  WITH CHECK ADD FOREIGN KEY([PlayerID])
REFERENCES [dbo].[DimPlayer] ([PlayerID])
GO
ALTER TABLE [dbo].[FactPrizeRedemptions]  WITH CHECK ADD  CONSTRAINT [FK__FactPrize__Prize__37A5467C] FOREIGN KEY([PrizeID])
REFERENCES [dbo].[DimPrize] ([PrizeID])
GO
ALTER TABLE [dbo].[FactPrizeRedemptions] CHECK CONSTRAINT [FK__FactPrize__Prize__37A5467C]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "FactActivityTransactions"
            Begin Extent = 
               Top = 6
               Left = 42
               Bottom = 336
               Right = 348
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vw_FactActivityTransactions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vw_FactActivityTransactions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "FactArcadeTransactions"
            Begin Extent = 
               Top = 6
               Left = 42
               Bottom = 148
               Right = 228
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 897
         Table = 1168
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1345
         SortOrder = 1413
         GroupBy = 1350
         Filter = 1345
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vw_FactArcadeTransactions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vw_FactArcadeTransactions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "FactPrizeRedemptions"
            Begin Extent = 
               Top = 6
               Left = 42
               Bottom = 148
               Right = 218
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vw_FactPrizeRedemptions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vw_FactPrizeRedemptions'
GO
USE [master]
GO
ALTER DATABASE [RetroWaveDW] SET  READ_WRITE 
GO
